demonlist
=======

**demonlist** is an asynchronous Python wrapper for https://demonlist.org/ API.